export class Sprite {
    constructor({ position, imageSrc, frameRate = 1, animations, frameBuffer = 7, loop = true, autoplay = true, context }) {
        this.position = position;
        this.image = new Image();
        this.image.onload = () => {
            this.loaded = true;
            this.frameWidth = this.image.width / this.frameRate;
            this.frameHeight = this.image.height;
        };
        this.image.src = imageSrc;
        this.loaded = false;
        this.frameRate = frameRate;
        this.currentFrame = 0;
        this.elapsedFrames = 0;
        this.frameBuffer = frameBuffer;
        this.animations = animations;
        this.loop = loop;
        this.autoplay = autoplay;
        this.currentAnimation = null;
        this.c = context;

        if (this.animations) {
            for (let key in this.animations) {
                const image = new Image();
                image.src = this.animations[key].imageSrc;
                this.animations[key].image = image;
            }
        }
    }

    setAnimation(name) {
        if (this.currentAnimation === name) return;

        const anim = this.animations[name];
        this.image = anim.image;
        this.frameRate = anim.frameRate;
        this.currentFrame = 0;
        this.elapsedFrames = 0;
        this.currentAnimation = name;

        this.frameWidth = this.image.width / this.frameRate;
        this.frameHeight = this.image.height;
    }

    draw() {
        if (!this.loaded) return;

        const cropbox = {
            position: {
                x: this.frameWidth * this.currentFrame,
                y: 0
            },
            width: this.frameWidth,
            height: this.frameHeight
        };

        this.c.save();
        this.c.translate(this.position.x + cropbox.width / 2, this.position.y + cropbox.height / 2);
        this.c.rotate(0);
        this.c.drawImage(
            this.image,
            cropbox.position.x,
            cropbox.position.y,
            cropbox.width,
            cropbox.height,
            -cropbox.width / 2,
            -cropbox.height / 2,
            cropbox.width,
            cropbox.height
        );
        this.c.restore();

        this.updateFrames();
    }

    play() {
        this.autoplay = true;
    }

    updateFrames() {
        if (!this.autoplay) return;

        this.elapsedFrames++;

        if (this.elapsedFrames % this.frameBuffer === 0) {
            if (this.currentFrame < this.frameRate - 1) {
                this.currentFrame++;
            } else if (this.loop) {
                this.currentFrame = 0;
            }
        }
    }
}
