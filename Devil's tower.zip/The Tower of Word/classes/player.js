import { Sprite } from "./sprite.js";

export class Player {
    constructor(context) {
        this.c = context;
        this.jump = 2;
        this.speed = 10;
        this.position = { x: 100, y: 10 };
        this.velocity = { x: 0, y: 1 };
        this.width = 256;
        this.height = 256;
        this.lastDirection = "right";
        this.isJumping = false;

        this.sprite = new Sprite({
            position: this.position,
            imageSrc: './img/idle.png',
            frameRate: 4,
            frameBuffer: 8,
            context: this.c,
            animations: {
                idle: {
                    imageSrc: './img/idle.png',
                    frameRate: 4,
                },
                run: {
                    imageSrc: './img/run.png',
                    frameRate: 8,
                },
                jump: {
                    imageSrc: './img/jump.png',
                    frameRate: 6,
                },
                runLeft: {
                    imageSrc: './img/runLeft.png',
                    frameRate: 8,
                },
                jumpLeft: {
                    imageSrc: './img/jumpLeft.png',
                    frameRate: 6,
                },
                idleLeft: {
                    imageSrc: './img/idleLeft.png',
                    frameRate: 4,
                }
            }
        });
    }

    update(gravity, keys, verifyJump, canvas) {
        this.velocity.x = 0;
        this.velocity.y += gravity;

        const isPressingRight = keys["ArrowRight"] || keys["KeyD"];
        const isPressingLeft = keys["ArrowLeft"] || keys["KeyA"];
        const isPressingJump = keys["Space"] || keys["ArrowUp"];

        // Pulo
        if (isPressingJump && verifyJump() && !this.isJumping) {
            this.velocity.y = -this.speed * 2;
            this.isJumping = true;

            if (this.lastDirection === "right") {
                this.sprite.setAnimation("jump");
            } else {
                this.sprite.setAnimation("jumpLeft");
            }
        }

        // Movimentação lateral (só troca se não estiver pulando)
        if (!this.isJumping) {
            if (isPressingRight) {
                this.velocity.x = this.speed;
                this.lastDirection = "right";
                this.sprite.setAnimation("run");
            } else if (isPressingLeft) {
                this.velocity.x = -this.speed;
                this.lastDirection = "left";
                this.sprite.setAnimation("runLeft");
            } else {
                if (this.lastDirection === "right") {
                    this.sprite.setAnimation("idle");
                } else {
                    this.sprite.setAnimation("idleLeft");
                }
            }
        }

        // Atualiza posição
        this.position.x += this.velocity.x;
        this.position.y += this.velocity.y;

        // Limites da tela
        if (this.position.x < 0) this.position.x = 0;
        if (this.position.x + this.width > canvas.width) this.position.x = canvas.width - this.width;

        if (this.position.y + this.height > canvas.height) {
            this.position.y = canvas.height - this.height;
            this.velocity.y = 0;
            this.jump = 2;
            this.isJumping = false;
        }

        if (this.position.y < 0) {
            this.position.y = 0;
            this.velocity.y = 0;
        }

        this.sprite.position = this.position;
        this.sprite.draw();
    }
}
