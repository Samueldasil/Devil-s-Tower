import { Player } from "./classes/player.js";

// Seleção do canvas e contexto
const canvas = document.querySelector('canvas');
const c = canvas.getContext('2d');

// Configuração do tamanho do canvas
canvas.width = 64 * 16;
canvas.height = 64 * 9;

// Fundo da página
document.body.style.backgroundColor = "black";

// Variáveis globais
const keys = {};
let jumptime = 0;
const gravity = 0.9;

// Criação do jogador
const player = new Player(c);

// Função para verificar se o jogador pode pular
function verifyJump() {
    if (player.jump > 0 && Date.now() - jumptime > 300) {
        player.jump--;
        jumptime = Date.now();
        return true;
    }

    if (player.position.y + player.height + player.velocity.y >= canvas.height - 140 && player.jump === 2) {
        player.jump--;
        return true;
    }

    return false;
}

// Eventos de teclado
document.addEventListener("keydown", (e) => {
    keys[e.code] = true;
});

document.addEventListener("keyup", (e) => {
    keys[e.code] = false;
});

// Loop principal
function animate() {
    c.fillStyle = 'white';
    c.fillRect(0, 0, canvas.width, canvas.height);

    player.update(gravity, keys, verifyJump, canvas); // Atualiza e desenha o jogador

    requestAnimationFrame(animate); // Continua o loop
}

animate();
